import { sql, connectNeon } from "./db.js";

const employees = [
  { id: 1, name: "Alice Johnson", department: "IT", title: "Software Engineer", dateOfBirth: "1990-03-15", startDate: "2023-01-15", imgUrl: "https://randomuser.me/api/portraits/women/21.jpg" },
  { id: 2, name: "Bob Smith", department: "Marketing", title: "Marketing Manager", dateOfBirth: "1985-11-23", startDate: "2018-09-15", imgUrl: "https://randomuser.me/api/portraits/men/22.jpg" },
  { id: 3, name: "Carol Martinez", department: "Finance", title: "Financial Analyst", dateOfBirth: "1992-07-08", startDate: "2024-03-12", imgUrl: "https://randomuser.me/api/portraits/women/23.jpg" },
  { id: 4, name: "David Lee", department: "IT", title: "Network Administrator", dateOfBirth: "1988-02-19", startDate: "2016-04-20", imgUrl: "https://randomuser.me/api/portraits/men/24.jpg" },
  { id: 5, name: "Eva Brown", department: "Finance", title: "Accountant", dateOfBirth: "1991-12-30", startDate: "2017-11-05", imgUrl: "https://randomuser.me/api/portraits/women/25.jpg" },
  { id: 6, name: "Frank Wilson", department: "IT", title: "DevOps Engineer", dateOfBirth: "1982-08-14", startDate: "2025-05-10", imgUrl: "https://randomuser.me/api/portraits/men/26.jpg" },
  { id: 7, name: "Grace Kim", department: "Marketing", title: "Content Strategist", dateOfBirth: "1989-06-25", startDate: "2020-02-28", imgUrl: "https://randomuser.me/api/portraits/women/27.jpg" },
  { id: 8, name: "Henry Carter", department: "Finance", title: "Financial Planner", dateOfBirth: "1987-01-11", startDate: "2023-07-01", imgUrl: "https://randomuser.me/api/portraits/men/28.jpg" },
  { id: 9, name: "Isabella Diaz", department: "IT", title: "System Analyst", dateOfBirth: "1993-10-05", startDate: "2021-05-17", imgUrl: "https://randomuser.me/api/portraits/women/29.jpg" },
  { id: 10, name: "Jack Thompson", department: "Finance", title: "Treasury Analyst", dateOfBirth: "1983-04-22", startDate: "2016-12-01", imgUrl: "https://randomuser.me/api/portraits/men/30.jpg" },
  { id: 11, name: "Karen White", department: "IT", title: "Product Manager", dateOfBirth: "1986-09-14", startDate: "2015-07-18", imgUrl: "https://randomuser.me/api/portraits/women/31.jpg" },
  { id: 12, name: "Liam Scott", department: "Marketing", title: "SEO Specialist", dateOfBirth: "1990-05-30", startDate: "2024-11-20", imgUrl: "https://randomuser.me/api/portraits/men/32.jpg" },
  { id: 13, name: "Mia Adams", department: "Finance", title: "Budget Analyst", dateOfBirth: "1984-12-27", startDate: "2013-09-25", imgUrl: "https://randomuser.me/api/portraits/women/33.jpg" },
  { id: 14, name: "Nathan Walker", department: "IT", title: "IT Support Specialist", dateOfBirth: "1987-03-02", startDate: "2017-06-19", imgUrl: "https://randomuser.me/api/portraits/men/34.jpg" },
  { id: 15, name: "Olivia Harris", department: "Finance", title: "Controller", dateOfBirth: "1994-08-21", startDate: "2023-09-30", imgUrl: "https://randomuser.me/api/portraits/women/35.jpg" },
  { id: 16, name: "Paul Robinson", department: "IT", title: "System Architect", dateOfBirth: "1981-11-10", startDate: "2012-04-30", imgUrl: "https://randomuser.me/api/portraits/men/36.jpg" },
  { id: 17, name: "Quinn Evans", department: "Marketing", title: "Brand Manager", dateOfBirth: "1990-02-18", startDate: "2018-11-08", imgUrl: "https://randomuser.me/api/portraits/women/37.jpg" },
  { id: 18, name: "Rachel Green", department: "Finance", title: "Business Development", dateOfBirth: "1985-07-16", startDate: "2025-01-05", imgUrl: "https://randomuser.me/api/portraits/women/38.jpg" },
  { id: 19, name: "Samuel Baker", department: "IT", title: "Compensation Analyst", dateOfBirth: "1992-05-07", startDate: "2019-03-29", imgUrl: "https://randomuser.me/api/portraits/men/39.jpg" },
  { id: 20, name: "Tina Wright", department: "Marketing", title: "Digital Marketing Specialist", dateOfBirth: "1989-09-25", startDate: "2017-01-23", imgUrl: "https://randomuser.me/api/portraits/women/40.jpg" },
];

const projects = [
  { projectName: "Website Redesign", description: "A complete redesign of the company website to improve user experience and SEO.", employees: [1], projectComplexity: "Medium", startDate: "2023-02-01" },
  { projectName: "Financial System Upgrade", description: "Upgrade the financial system to improve efficiency and security.", employees: [5], projectComplexity: "High", startDate: "2023-05-15" },
  { projectName: "Cloud Infrastructure Migration", description: "Migrate the existing IT infrastructure to the cloud to reduce costs and improve scalability.", employees: [6], projectComplexity: "Critical", startDate: "2024-01-10" },
  { projectName: "Marketing Campaign 2023", description: "Launch a new marketing campaign to increase brand awareness and drive sales.", employees: [7], projectComplexity: "Low", startDate: "2023-03-20" },
  { projectName: "Data Security Audit", description: "Conduct a comprehensive audit of the company's data security practices.", employees: [9], projectComplexity: "High", startDate: "2023-08-01" },
  { projectName: "Product Launch", description: "Plan and execute the launch of the company's new product line.", employees: [11], projectComplexity: "Medium", startDate: "2023-11-15" },
];

async function seed() {
  await connectNeon();

  console.log("[seed] clearing existing data...");
  await sql`DELETE FROM project_employees`;
  await sql`DELETE FROM projects`;
  await sql`DELETE FROM employees`;

  console.log("[seed] inserting employees...");
  const idMap = new Map(); // sample numeric id -> generated employee_id string
  for (const e of employees) {
    const employee_id = `EMP-${String(e.id).padStart(4, "0")}`;
    idMap.set(e.id, employee_id);
    await sql`
      INSERT INTO employees
        (employee_id, name, department, title, date_of_birth, start_date, img_url)
      VALUES
        (${employee_id}, ${e.name}, ${e.department}, ${e.title}, ${e.dateOfBirth}, ${e.startDate}, ${e.imgUrl})
    `;
  }

  console.log("[seed] inserting projects...");
  let projectSeq = 1;
  for (const p of projects) {
    const project_id = `PRJ-${String(projectSeq).padStart(4, "0")}`;
    projectSeq += 1;
    await sql`
      INSERT INTO projects
        (project_id, project_name, description, project_complexity, start_date)
      VALUES
        (${project_id}, ${p.projectName}, ${p.description}, ${p.projectComplexity}, ${p.startDate})
    `;
    for (const numericEmpId of p.employees) {
      const employee_id = idMap.get(numericEmpId);
      await sql`
        INSERT INTO project_employees (project_id, employee_id)
        VALUES (${project_id}, ${employee_id})
      `;
    }
  }

  console.log(`[seed] done — ${employees.length} employees, ${projects.length} projects`);
  process.exit(0);
}

seed().catch((err) => {
  console.error("[seed] failed:", err);
  process.exit(1);
});
